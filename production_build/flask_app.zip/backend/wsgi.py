# project_root/wsgi.py
from app import create_app

application = create_app()
